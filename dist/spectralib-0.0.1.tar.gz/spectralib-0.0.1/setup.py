from setuptools import setup, find_packages

setup(
    name="spectralib",
    version="0.0.1",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 1 - Planning",
    ],
    author="Your Name",
    author_email="your.email@example.com",
    description="A short description of your package",
    long_description="A longer description of your package",
    long_description_content_type="text/markdown",
    url="https://github.com/jack-white1/spectralib",
)
